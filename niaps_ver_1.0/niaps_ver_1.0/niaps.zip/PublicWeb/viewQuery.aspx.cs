﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace niaps_ver_1._0.PublicWeb
{
    public partial class viewQuery : System.Web.UI.Page
    {
        private niapsEntities1 db = new niapsEntities1();
        public string getStaffId()
        {
            string sId = Request.QueryString["staffId"].ToString();
            return sId;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string name = Session["fullName"].ToString();
                string role = Session["role"].ToString();
            }
            catch (Exception)
            {
                Response.Redirect("../Default.aspx");
            }
            if (!IsPostBack)
            {
                string sId = getStaffId();
                var staffQuery = db.queries.Where(st => st.staffId == sId).First();
                string stid = staffQuery.staffId;
                natuerOfQuery.Text = staffQuery.natureOfQuery;
                issuedBy.Text = staffQuery.issuedBy;
                dateIssued.Text = staffQuery.dateIssued.ToShortDateString();
                var staffRec = db.staffRecords.Where(st => st.staffId == sId).First();
                string lname = staffRec.lName;
                string fname = staffRec.fName;
                string mname = staffRec.middleName;
                Names.Text = lname + ", " + fname + "&nbsp; " + mname + "&nbsp;&nbsp;&nbsp;" + stid;

            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (rp.Text == string.Empty) {
                rpError.Text = "*";
            }
            try
            {
               string sId = getStaffId();
               var iq = db.queries.FirstOrDefault(u => u.staffId == sId);
                iq.reply = rp.Text;
                iq.status = "active";
                iq.dateReplied = DateTime.Now;
                db.queries.Add(iq);
                db.SaveChanges();
                rpError.Text = "";
                msg.Text = "Reply posted successfully";
            }
            catch (Exception)
            {
                msg.Text = "error posting your reply...try again";
                rpError.Text = "";
            }
        }
    }
}