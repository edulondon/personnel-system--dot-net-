﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Globalization;

namespace niaps_ver_1._0.PrivateWeb
{
    public partial class createQuery : System.Web.UI.Page
    {
        private niapsEntities1 db = new niapsEntities1();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string name = Session["fullName"].ToString();
                string role = Session["role"].ToString();
            }
            catch (Exception)
            {
                Response.Redirect("../Default.aspx");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                query iq = new query();
               
                iq.staffId = sid.SelectedValue;
                iq.natureOfQuery = natuerOfQuery.Text;
                iq.status = status.Text;
                iq.actionTaken = action.Text;
                iq.issuedBy = issuedBy.Text;
                string result = Request.Form["dati"];
                CultureInfo provider = new CultureInfo("en-US");
                Thread.CurrentThread.CurrentCulture = provider;
                iq.dateIssued = DateTime.Parse(result);
                //iq.dateReplied = dat.Text;
                db.queries.Add(iq);
                db.SaveChanges();
                msg.Text = "Query posted successfully";
                 natuerOfQuery.Text ="";
                action.Text="";
                issuedBy.Text = "";
                
            }
            catch (Exception ex)
            {
                msg.Text = ex.Message;
            }
        }

        protected void sid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sids = sid.SelectedValue;
            var detail = db.staffRecords.Where(de => de.staffId == sids).First();
            otherNames.Text = detail.fName + " &nbsp;&nbsp;&nbsp;" + detail.middleName + "   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbspId: " + detail.staffId;

        }
    }
}