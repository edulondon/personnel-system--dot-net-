﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Globalization;

namespace niaps_ver_1._0.PrivateWeb
{
    public partial class regAsset : System.Web.UI.Page
    {
        private niapsEntities1 db = new niapsEntities1(); 

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string name = Session["fullName"].ToString();
                string role = Session["role"].ToString();
            }
            catch (Exception)
            {
                Response.Redirect("../Default.aspx");
            }
        }

        protected void register_Click(object sender, EventArgs e)
        {
            try
            {
                assetRecord ar = new assetRecord();
                if (dateP.Text == string.Empty)
                {
                    dError.Text = "*";
                }
                else
                    if (aname.Text == string.Empty)
                    {
                        aError.Text = "*";
                    }
                    else
                        if (aid.Text == string.Empty)
                        {
                            assetError.Text = "*";
                        }
                        else if (pnumber.Text == string.Empty)
                        {
                            ipError.Text = "*";
                        }
                        else if (sum.Text == string.Empty)
                        {
                            siError.Text = "*";
                        }
                        else if (ven.Text == string.Empty)
                        {
                            vendorError.Text = "*";
                        }
                        else if (remark.Text == string.Empty)
                        {
                            remarkError.Text = "*";
                        }
                        else if (rdept.Text == string.Empty)
                        {
                            rdError.Text = "*";
                        }
                        else if (cp.Text == string.Empty)
                        {
                            copError.Text = "*";
                        }
                        else if (status.Text == string.Empty)
                        {
                            statusError.Text = "*";
                        }
                        else
                        {
                            ar.assetId = aid.Text;
                            ar.name = aname.Text;
                            DateTime result;
                            CultureInfo provider = new CultureInfo("en-US");
                            Thread.CurrentThread.CurrentCulture = provider;
                            result = DateTime.Parse(dateP.Text);
                            ar.datePurchased = result;
                            ar.receivingDept = rdept.Text;
                            ar.cost = Convert.ToDecimal(cp.Text);
                            ar.remark = remark.Text;
                            ar.insurance = insurance.SelectedValue;
                            ar.policyNumber = pnumber.Text;
                            ar.sumInsured = Convert.ToDecimal(sum.Text);
                            DateTime result2 = DateTime.Parse(edate.Text);
                            ar.expirydate = result2;
                            DateTime result3 = DateTime.Parse(cdate.Text);
                            ar.coverDate = result3;
                            ar.vendor = ven.Text;
                            ar.status = status.Text;
                            db.assetRecords.Add(ar);
                            db.SaveChanges();

                            cp.Text = "";
                            sum.Text = "";
                            pnumber.Text = "";
                            remark.Text = "";
                            rdept.Text = "";
                            status.Text = "";
                            ven.Text = "";
                            remark.Text = "";
                            aid.Text = "";
                            aname.Text = "";
                            dateP.Text = "";
                            edate.Text = "";
                            cdate.Text = "";
                            msg.Text = "Asset Registered Successfully";
                        }
            }
            catch (Exception)
            {
                msg.Text = "1 or 2 fields are empty";
            }
        }

        protected void edate_TextChanged(object sender, EventArgs e)
        {
            if (cdate.Text == string.Empty)
            {
                dateError.Text = "*";
            }
            if (edate.Text == string.Empty)
            {
                dateError2.Text = "*";
            }
            else
            {
                //try
                //{
                CultureInfo provider = new CultureInfo("en-US");
                Thread.CurrentThread.CurrentCulture = provider;

                DateTime coverD = DateTime.Parse(cdate.Text);
                DateTime expiryD = DateTime.Parse(edate.Text);
                DateTime Pdate = DateTime.Parse(dateP.Text);
                //int pd = Pdate.Year;
                //int cd = coverD.Year;
                int i = expiryD.Year - coverD.Year;
                if (i < 1)
                {
                    dateError2.Text = "Expiry date must be > Cover date";
                }
                if (i > 1)
                {
                    dateError2.Text = "Policy can only run for one year";
                }
                if (Pdate > coverD)
                {
                    dError.Text = "Date purchase can't be > cover date";
                }


            }
        }

        
        
    }
}